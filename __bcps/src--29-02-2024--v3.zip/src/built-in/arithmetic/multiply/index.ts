export * from './multiply.function-definition';
export * from './multiply.trait';
