export * from './negate.function-definition.infer';
export * from './negate.function-definition';
export * from './negate.trait.infer';
export * from './negate.trait';
