export interface INegateFunction<GReturn> {
  (): GReturn;
}
