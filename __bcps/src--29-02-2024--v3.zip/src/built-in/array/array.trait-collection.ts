import { IReadonlyArrayTraitCollection } from './readonly-array.trait-collection';

export interface IArrayTraitCollection<GValue> extends // traits
  IReadonlyArrayTraitCollection<GValue>
//
{
}
