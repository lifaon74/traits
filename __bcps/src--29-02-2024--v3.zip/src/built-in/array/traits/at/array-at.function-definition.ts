export interface IArrayAtFunction<GValue> {
  (
    index: number,
  ): GValue | undefined;
}

