import { IArrayAtFunction } from './array-at.function-definition';

export interface IArrayAtTrait<GValue> {
  at: IArrayAtFunction<GValue>;
}

