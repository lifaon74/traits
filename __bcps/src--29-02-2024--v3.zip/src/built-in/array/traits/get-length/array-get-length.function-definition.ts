export interface IArrayGetLengthFunction {
  (): number;
}

