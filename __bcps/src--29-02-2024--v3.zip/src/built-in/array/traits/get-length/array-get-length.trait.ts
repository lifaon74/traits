import { IArrayGetLengthFunction } from './array-get-length.function-definition';

export interface IArrayGetLengthTrait {
  getLength: IArrayGetLengthFunction;
}

