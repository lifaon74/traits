export * from './array-get-length.function-definition';
export * from './array-get-length.trait';
