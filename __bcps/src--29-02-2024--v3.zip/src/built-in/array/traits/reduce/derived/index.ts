export * from './array-reduce-function.create.using-get-length-and-at';
