export interface INotEqualsFunction<GValue> {
  (
    value: GValue,
  ): boolean;
}
