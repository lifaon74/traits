export interface IIteratorResultGetValueFunction<GOut> {
  (): GOut;
}
