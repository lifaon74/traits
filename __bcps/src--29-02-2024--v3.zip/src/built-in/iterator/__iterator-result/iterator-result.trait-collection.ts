import { IIteratorResultGetValueTrait } from './get-value/iterator-result-get-value.trait';

export interface IIteratorResultTraitCollection<GIn, GOut, GReturn> extends // traits
  IIteratorResultGetValueTrait<GIn, GOut, GReturn>
//
{
}


