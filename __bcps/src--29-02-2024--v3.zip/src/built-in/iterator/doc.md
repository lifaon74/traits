https://github.com/tc39/proposal-iterator-helpers

https://tc39.es/proposal-iterator-helpers/

