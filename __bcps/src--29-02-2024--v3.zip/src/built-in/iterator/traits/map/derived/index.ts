export * from './iterator-map-function.create.using-next';
