import { NEW } from '../../../others/new/new.symbol.constant';
import { IIteratorNewFunction } from './iterator-new.function-definition';

export interface IIteratorNewTrait {
  [NEW]: IIteratorNewFunction;
}
