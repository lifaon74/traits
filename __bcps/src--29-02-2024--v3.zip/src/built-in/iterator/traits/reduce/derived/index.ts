export * from './iterator-reduce-function.create.using-next';
