export * from './map-delete.function-definition';
export * from './map-delete.trait';
