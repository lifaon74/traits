export interface IMapDeleteFunction<GKey> {
  (
    key: GKey,
  ): void;
}
