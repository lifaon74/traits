export * from './map-get-size.function-definition';
export * from './map-get-size.trait';
