export interface IMapGetSizeFunction {
  (): number;
}
