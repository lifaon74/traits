import { IMapGetSizeFunction } from './map-get-size.function-definition';

export interface IMapGetSizeTrait {
  getSize: IMapGetSizeFunction;
}

