export interface IMapHasFunction<GKey> {
  (
    key: GKey,
  ): boolean;
}
