export * from './create-instance-of-function';
export * from './create-instance-of-tuple';
export * from './create-virtual-constructor';
export * from './is-instance-of';
