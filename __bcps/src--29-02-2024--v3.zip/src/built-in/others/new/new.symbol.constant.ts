export const NEW = Symbol('new');
