export interface IToStringFunction {
  (): string;
}

