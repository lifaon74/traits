import { IToStringFunction } from './to-string.function-definition';

export interface IToStringTrait {
  toString: IToStringFunction;
}

