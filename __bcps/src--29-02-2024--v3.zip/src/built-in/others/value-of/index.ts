export * from './value-of.function-definition';
export * from './value-of.trait';
