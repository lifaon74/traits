export interface IValueOfFunction<GValue> {
  (): GValue;
}

