export type IImplementedTrait<GTrait extends object, GBaseClass extends (abstract new (...args: any) => any) | undefined> =
  GBaseClass extends (abstract new (...args: infer GParameters) => infer GInstance)
    ? (
      Omit<GBaseClass, 'new'>
      & {
      new(
        ...args: GParameters
      ): (GInstance & GTrait);
    }
      )
    : {
      new(): GTrait;
    }
  ;

export function implementTrait<GTrait extends object>(
  trait: GTrait,
): IImplementedTrait<GTrait, undefined>;
export function implementTrait<GTrait extends object, GBaseClass extends (abstract new (...args: any) => any)>(
  trait: GTrait,
  baseClass: GBaseClass,
): IImplementedTrait<GTrait, GBaseClass>;
export function implementTrait<GTrait extends object, GBaseClass extends (abstract new (...args: any) => any) | undefined>(
  trait: GTrait,
  baseClass?: GBaseClass,
): IImplementedTrait<GTrait, GBaseClass> {
  const _class: any = baseClass === void 0
    ? class {
    }
    : class extends baseClass {
    };

  Object.assign(_class.prototype, trait);

  return _class;
}


// const a = implementTrait({
//   read(this: { url: string }): string {
//     return '';
//   },
// }, class {
//   url!: string;
// });
//
// const b = new a();
// b.read();
