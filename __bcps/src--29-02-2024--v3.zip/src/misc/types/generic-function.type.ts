export type IGenericFunction = (...args: any[]) => any;
