export * from './generic-function.type';
