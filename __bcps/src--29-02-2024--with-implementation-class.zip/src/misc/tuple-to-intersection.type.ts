import { TupleToUnion } from './tuple-to-union.type';
import { UnionToIntersection } from './union-to-intersection.type';

export type TupleToIntersection<T extends unknown[]> = UnionToIntersection<TupleToUnion<T>>;
