export type TupleToUnion<T extends unknown[]> = T[number];
