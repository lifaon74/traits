export const NEW = Symbol('NEW');
