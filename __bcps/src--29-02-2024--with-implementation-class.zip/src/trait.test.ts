import { NEW } from './new.constant';
import { Implementation } from './traits/implementation.class';
import { mixin } from './traits/mixin.function';

interface AddTrait<GIn, GOut> {
  add(
    value: GIn,
  ): GOut;

  sub<GSub>(sub: GSub): number;
}

interface INumberAddTraitImplementationThis<GOut> {
  readonly [NEW]: (value: number) => GOut;
  readonly value: number;
}

type INumberAddTraitImplementation<GIn, GOut> = Implementation<AddTrait<GIn, GOut>, INumberAddTraitImplementationThis<GOut>>;

const NumberAddTraitImplementation = new Implementation<AddTrait<any, any>, INumberAddTraitImplementationThis<any>>({
  add<GIn, GOut>(this: INumberAddTraitImplementationThis<GOut>, value: GIn): GOut {
    throw 'TODO';
  },
  sub<GSub>(sub: GSub): number {
    throw 'TODO';
  },
});

describe('traits', () => {

  class Num extends mixin<[INumberAddTraitImplementation<Num, Num>]>(NumberAddTraitImplementation) {
    readonly value: number;

    constructor(
      value: number,
    ) {
      super();
      this.value = value;
    }

    [NEW](value: number): Num  {
      return new Num(value);
    };
  }

  const a = new Num(1);
  const b = a.add(new Num(2));
  a.sub<number>(5);

});
/*-------------*/





// SetLayerTraitImplementation.implement(4)

interface SetPositionTrait {
  setPosition(
    position: number,
  ): this;
}

const SetPositionTraitImplementation = new Implementation<SetPositionTrait, { position: number }>({
  setPosition(this: { position: number }, position: number): any {
    this.position = position;
    return this;
  },
});

// Reflect.apply(setLayerImplementation, {layer: 'p'}, ['a'])
// setLayerImplementation.call({layer: 5},5)

class ABC extends mixin(SetLayerTraitImplementation, SetPositionTraitImplementation) {
  layer: number;
}

const a = new ABC();

a.setLayer(45);

