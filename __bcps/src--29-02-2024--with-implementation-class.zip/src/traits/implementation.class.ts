/* TYPES */

export type IImplementation<GTrait extends object, GThis> = {
  [GKey in keyof GTrait]: GTrait[GKey] extends (...args: infer GArgs) => infer GReturn
    ? (
      this: GThis,
      ...args: GArgs
    ) => GReturn
    : never;
}
export type IImplementedTrait<GTrait extends object, GThis, GTarget extends {}> =
  GTarget & IImplementation<GTrait, GThis>;

/* CLASS */

export class Implementation<GTrait extends object, GThis> {
  readonly #implementation: IImplementation<GTrait, GThis>;

  constructor(
    implementation: IImplementation<GTrait, GThis>
  ) {
    this.#implementation = implementation;
  }

  // get implementation(): IImplementation<GTrait, GThis> {
  //   return this.#implementation;
  // }

  implement<GTarget extends {}>(
    target: GTarget
  ): IImplementedTrait<GTrait, GThis, GTarget> {
    return Object.assign(target, this.#implementation);
  }
}
