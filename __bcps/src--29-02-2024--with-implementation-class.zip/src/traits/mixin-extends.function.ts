import { IImplementation, Implementation } from './implementation.class';
import { TupleToIntersection } from '../misc/tuple-to-intersection.type';

export type IMixImplementations<GImplementations extends Implementation<any, any>[]> = TupleToIntersection<{
  [GKey in keyof GImplementations]: GImplementations[GKey] extends Implementation<infer GTrait, infer GThis>
    ? IImplementation<GTrait, GThis>
    : never;
}>;

export type IMixinExtendsResult<GBaseClass extends (abstract new (...args: any) => any) | undefined, GImplementations extends Implementation<any, any>[]> =
  GBaseClass extends (abstract new (...args: infer GParameters) => infer GInstance)
    ? (
      Omit<GBaseClass, 'new'>
      & {
      new(
        ...args: GParameters
      ): (GInstance & IMixImplementations<GImplementations>);
    }
      )
    : {
      new(): IMixImplementations<GImplementations>;
    }
  ;

export function mixinExtends<GBaseClass extends (abstract new (...args: any) => any) | undefined, GImplementations extends Implementation<any, any>[]>(
  baseClass: GBaseClass | undefined,
  ...implementations: GImplementations
): IMixinExtendsResult<GBaseClass, GImplementations> {
  const _class: any = baseClass === void 0
    ? class {
    }
    : class extends baseClass {
    };

  for (let i = 0, l = implementations.length; i < l; i++) {
    implementations[i].implement(_class.prototype);
  }

  return _class;
}
