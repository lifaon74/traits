import { Implementation } from './implementation.class';
import { IMixinExtendsResult, mixinExtends } from './mixin-extends.function';

export type IMixinResult<GImplementations extends Implementation<any, any>[]> =
  IMixinExtendsResult<undefined, GImplementations>;

export function mixin<GImplementations extends Implementation<any, any>[]>(
  ...implementations: GImplementations
): IMixinResult<GImplementations> {
  return mixinExtends<undefined, GImplementations>(void 0, ...implementations);
}
