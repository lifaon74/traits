// export type TKeyValueMap = { [key: string]: any };
// export type TKeyValueMap = { };
// export type TKeyValueMap = object;
// export type TKeyValueMap = any;

// export type TInferEventMapKeys<GEventMap extends TKeyValueMap> = Extract<keyof GEventMap, string>;
// export type TInferEventMapKeys<GEventMap extends TKeyValueMap> = keyof GEventMap;
//
// export type TInferEventMapValues<GEventMap extends TKeyValueMap> = GEventMap[TInferEventMapKeys<GEventMap>];

/*----*/

// export type TKeyValueMap = object;
// export type TInferKeyValueMapKeys<GKeyValueMap extends object> = Extract<keyof GKeyValueMap, string>;
// export type TInferKeyValueMapValues<GKeyValueMap extends object> = GKeyValueMap[TInferKeyValueMapKeys<GKeyValueMap>];
// export type TGenericKeyValueMap = { [key: string]: any };
//
// export type TKeyValueMapConstraint<GKeyValueMap, GExpectedKeyValueMap> = GKeyValueMap extends GExpectedKeyValueMap
//   ? TKeyValueMap
//   : never;
//
// // export type TGenericKeyValueMapConstraint<GKeyValueMap, GExpectedKeyValueMap> = GKeyValueMap extends GExpectedKeyValueMap
// //   ? TKeyValueMap
// //   : never;

/*----*/

import { TupleTypes } from '../../core/types/tuple-types';

/** KEY VALUE MAP **/

// export type TEmptyKeyValueMap = {};
// export type TGenericKeyValueMap = { [key: string]: any };
export type TGenericKeyValueMap = object;


/** KEY VALUE TUPLE **/

export type TKeyValueTuple<GKey, GValue> = [GKey, GValue];

export type TGenericKeyValueTuple = TKeyValueTuple<any, any>;

export type TInferKeyValueTupleGKey<GKeyValueTuple extends TGenericKeyValueTuple> =
  GKeyValueTuple extends TKeyValueTuple<infer GKey, any>
   ? GKey
   : never;

export type TInferKeyValueTupleGValue<GKeyValueTuple extends TGenericKeyValueTuple> =
  GKeyValueTuple extends TKeyValueTuple<any, infer GValue>
    ? GValue
    : never;


/** LIST **/

export type TGenericKeyValueTupleList = TGenericKeyValueTuple[];

export type TInferKeyValueTupleListKeyList<GKeyValueTupleList extends TGenericKeyValueTupleList> = {
  [GKey in keyof GKeyValueTupleList]: GKeyValueTupleList[GKey] extends TKeyValueTuple<infer GKey, any>
    ? GKey
    : never;
};

export type TInferKeyValueTupleListKeys<GKeyValueTupleList extends TGenericKeyValueTupleList> =
  TupleTypes<TInferKeyValueTupleListKeyList<GKeyValueTupleList>>;


export type TInferKeyValueTupleListValueFromKeyList<GKeyValueTupleList extends TGenericKeyValueTupleList, GSearchKey extends TInferKeyValueTupleListKeys<GKeyValueTupleList>> = {
  [GKey in keyof GKeyValueTupleList]: GKeyValueTupleList[GKey] extends TKeyValueTuple<GSearchKey, infer GValue>
    ? GValue
    : never;
};

export type TInferKeyValueTupleListValueFromKey<GKeyValueTupleList extends TGenericKeyValueTupleList, GSearchKey extends TInferKeyValueTupleListKeys<GKeyValueTupleList>> =
  TupleTypes<TInferKeyValueTupleListValueFromKeyList<GKeyValueTupleList, GSearchKey>>;

// export type TInferKeyValueTupleGValue<GKeyValueTuple extends TGenericKeyValueTuple> =
//   GKeyValueTuple extends TKeyValueTuple<any, infer GValue>
//     ? GValue
//     : never;

/** UNION **/

export type TEmptyKeyValueTupleUnion = never;
export type TGenericKeyValueTupleUnion = TGenericKeyValueTuple;

// export type TInferKeyValueTupleUnionGKey<GKeyValueTupleUnion extends TGenericKeyValueTupleUnion> =
//   TEmptyKeyValueTupleUnion extends GKeyValueTupleUnion
//     ? TInferKeyValueTupleGKey<GKeyValueTupleUnion>
//     : any;

export type TInferKeyValueTupleUnionGKey<GKeyValueTupleUnion extends TGenericKeyValueTupleUnion> =
  TInferKeyValueTupleGKey<GKeyValueTupleUnion>;

// export type TInferKeyValueTupleUnionGValue<GKeyValueTupleUnion extends TGenericKeyValueTupleUnion> =
//   TEmptyKeyValueTupleUnion extends GKeyValueTupleUnion
//     ? TInferKeyValueTupleGValue<GKeyValueTupleUnion>
//     : never;

export type TInferKeyValueTupleUnionGValue<GKeyValueTupleUnion extends TGenericKeyValueTupleUnion> =
  TInferKeyValueTupleGValue<GKeyValueTupleUnion>;

// const a: (never extends 'a' ? true: false); // true
// const a: ('a' extends never ? true: false); // false

export type TInferKeyValueTupleUnionGValueFromKeyStrict<GKeyValueTupleUnion extends TGenericKeyValueTuple, GKey extends TInferKeyValueTupleUnionGKey<GKeyValueTupleUnion>> =
  GKeyValueTupleUnion extends TKeyValueTuple<GKey, infer GValue>
    ? GValue
    : never;

// export type TInferKeyValueTupleUnionGValueFromKey<GKeyValueTupleUnion extends TGenericKeyValueTuple, GKey extends TInferKeyValueTupleUnionGKey<GKeyValueTupleUnion>> =
//   TEmptyKeyValueTupleUnion extends GKeyValueTupleUnion
//     ? TInferKeyValueTupleUnionGValueFromKeyStrict<GKeyValueTupleUnion, GKey>
//     : any;

export type TInferKeyValueTupleUnionGValueFromKey<GKeyValueTupleUnion extends TGenericKeyValueTuple, GKey extends TInferKeyValueTupleUnionGKey<GKeyValueTupleUnion>> =
  TInferKeyValueTupleUnionGValueFromKeyStrict<GKeyValueTupleUnion, GKey>;

export type TKeyValueMapToKeyValueTupleUnion<GObject extends object> = {
  [GKey in Extract<keyof GObject, string>]: TKeyValueTuple<GKey, GObject[GKey]>;
}[Extract<keyof GObject, string>];


export type TKeyValueTupleUnionToKeyValueMap<GKeyValueTupleUnion extends TGenericKeyValueTuple> = {
  [GKey in TInferKeyValueTupleUnionGKey<GKeyValueTupleUnion>]: GKeyValueTupleUnion extends TKeyValueTuple<GKey, infer GValue>
    ? GValue
    : never;
};

/**
 * Constraints GKeyValueTupleUnion to be a super set of GKeyValueTupleSubSetUnion
 */
export type TKeyValueTupleUnionSuperSetConstraint<GKeyValueTupleUnion extends TGenericKeyValueTuple, GKeyValueTupleSubSetUnion extends TGenericKeyValueTuple> =
  [GKeyValueTupleSubSetUnion] extends [GKeyValueTupleUnion]
    ? TGenericKeyValueTuple
    : never;

export type TKeyValueTupleUnionSubSetConstraint<GKeyValueTupleUnion extends TGenericKeyValueTuple, GKeyValueTupleSuperSetUnion extends TGenericKeyValueTuple> =
  [GKeyValueTupleUnion] extends [GKeyValueTupleSuperSetUnion]
    ? TGenericKeyValueTuple
    : never;

// type KeyValueTupleUnion = ['a', 1] | ['b', 2];
// type KeyValueTupleUnion2 = KeyValueTupleUnion | ['c', 3];

// const a: (KeyValueTupleUnion2 extends KeyValueTupleUnion ? true : false); // false
// const a: (KeyValueTupleUnion extends KeyValueTupleUnion2 ? true : false); // true
// const a: ([KeyValueTupleUnion2] extends [KeyValueTupleUnion] ? true : false); // false
// const a: ([KeyValueTupleUnion] extends [KeyValueTupleUnion2] ? true : false); // true
// const a: TKeyValueTupleUnionSuperSetConstraint<KeyValueTupleUnion, KeyValueTupleUnion2>; // never
// const a: TKeyValueTupleUnionSuperSetConstraint<KeyValueTupleUnion2, KeyValueTupleUnion>; // tuple
// const a: TKeyValueTupleUnionSuperSetConstraint<TGenericKeyValueTuple, KeyValueTupleUnion>; // tuple
// const a: TKeyValueTupleUnionSuperSetConstraint<KeyValueTupleUnion, TGenericKeyValueTuple>; // tuple
// const a: TKeyValueTupleUnionSuperSetConstraint<KeyValueTupleUnion, never>; // tuple
// const a: TKeyValueTupleUnionSuperSetConstraint<never, KeyValueTupleUnion>; // never

// const a: TInferKeyValueTupleGKey<KeyValueTupleUnion>;
// const a: TInferKeyValueTupleGValue<KeyValueTupleUnion>;
// const a: TInferKeyValueTupleUnionGValueFromKey<KeyValueTupleUnion, 'a'>;
// // const a: TInferKeyValueTupleUnionGValueFromKey<KeyValueTupleUnion, 'c'>;
// const a: TKeyValueMapToKeyValueTupleUnion<{ 'a': 1; 'b': 2 }>;
// const a: TInferKeyValueTupleGKey<TKeyValueMapToKeyValueTupleUnion<{ 'a': 1; 'b': 2 }>>;
// const a: TInferKeyValueTupleUnionGValueFromKey<TKeyValueMapToKeyValueTupleUnion<{ 'a': 1; 'b': 2 }>, 'b'>;

// const a: TKeyValueTupleToKeyValueMap<['a', 1]>;
// const a: TKeyValueTupleUnionToKeyValueMap<KeyValueTupleUnion> = null as any;
// const a: TKeyValueTupleUnionToKeyValueMap<never> = null as any;

/*----*/


export type TInferListenerCallbackFromKeyValueTupleUnionAndKey<GKeyValueTupleUnion extends TGenericKeyValueTuple, GKey extends TInferKeyValueTupleUnionGKey<GKeyValueTupleUnion>> =
  (value: TInferKeyValueTupleUnionGValueFromKey<GKeyValueTupleUnion, GKey>) => void;

export type TGenericListenerCallback = (value: any) => void;

export type TEventListenerOnUnsubscribe = () => void;


