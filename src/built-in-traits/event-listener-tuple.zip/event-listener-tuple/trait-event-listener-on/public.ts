export * from './trait-event-listener-on';

