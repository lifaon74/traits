import { Trait } from '../../../core/traits/trait-decorator';
import {
  TEmptyKeyValueTupleUnion, TEventListenerOnUnsubscribe, TGenericKeyValueTupleList, TGenericKeyValueTupleUnion,
  TInferKeyValueTupleListKeys, TInferKeyValueTupleListValueFromKey, TInferKeyValueTupleUnionGKey,
} from '../event-listener-types';




@Trait()
export abstract class TraitEventListenerOn<GSelf, GKeyValueTupleList extends TGenericKeyValueTupleList> {
  abstract on<GKey extends TInferKeyValueTupleListKeys<GKeyValueTupleList>>(
    this: GSelf,
    key: GKey,
    callback: (value: TInferKeyValueTupleListValueFromKey<GKeyValueTupleList, GKey>) => void,
  ): TEventListenerOnUnsubscribe;
}


export type TEmptyTraitEventListenerOn = TraitEventListenerOn<any, TEmptyKeyValueTupleUnion>; // OLD
// export type TGenericTraitEventListenerOn = TraitEventListenerOn<any, TGenericKeyValueTupleList>;
export type TGenericTraitEventListenerOn = TraitEventListenerOn<any, TGenericKeyValueTupleUnion>;

export type TInferTraitEventListenerOnGKeyValueTupleUnion<GTrait extends TEmptyTraitEventListenerOn> =
  GTrait extends TraitEventListenerOn<any, infer GKeyValueTupleUnion>
    ? GKeyValueTupleUnion
    : never;

export type TInferTraitEventListenerOnGKeyValueTupleList<GTrait extends TGenericTraitEventListenerOn> =
  GTrait extends TraitEventListenerOn<any, infer GKeyValueTupleList>
    ? GKeyValueTupleList
    : never;

