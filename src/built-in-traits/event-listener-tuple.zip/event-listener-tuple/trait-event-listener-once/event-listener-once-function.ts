import {
  TEventListenerOnUnsubscribe, TInferKeyValueTupleListKeys, TInferKeyValueTupleListValueFromKey,
  TInferKeyValueTupleUnionGKey,
  TInferKeyValueTupleUnionGValueFromKey,
  TInferListenerCallbackFromKeyValueTupleUnionAndKey
} from '../event-listener-types';
import {
  TGenericTraitEventListenerOn, TInferTraitEventListenerOnGKeyValueTupleList,
  TInferTraitEventListenerOnGKeyValueTupleUnion
} from '../trait-event-listener-on/trait-event-listener-on';

export function EventListenerOnce<GTarget extends TGenericTraitEventListenerOn, GKey extends TInferKeyValueTupleListKeys<TInferTraitEventListenerOnGKeyValueTupleList<GTarget>>>(
  target: GTarget,
  key: GKey,
  callback: (value: TInferKeyValueTupleListValueFromKey<TInferTraitEventListenerOnGKeyValueTupleList<GTarget>, GKey>) => void,
): TEventListenerOnUnsubscribe {
  // TODO
  const unsubscribe: TEventListenerOnUnsubscribe = (target.on as any)(key, (value: TInferKeyValueTupleListValueFromKey<TInferTraitEventListenerOnGKeyValueTupleList<GTarget>, GKey>) => {
    unsubscribe();
    callback(value);
  });
  return unsubscribe;
}
