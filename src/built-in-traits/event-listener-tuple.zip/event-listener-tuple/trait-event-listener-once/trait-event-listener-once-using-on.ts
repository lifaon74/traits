import { Trait } from '../../../core/traits/trait-decorator';
import {
  TEventListenerOnUnsubscribe, TGenericKeyValueTupleList, TInferKeyValueTupleListKeys,
  TInferKeyValueTupleListValueFromKey,
} from '../event-listener-types';
import { TraitEventListenerOn } from '../trait-event-listener-on/trait-event-listener-on';
import { EventListenerOnce } from './event-listener-once-function';
import { TraitEventListenerOnce } from './trait-event-listener-once';

@Trait()
export abstract class TraitEventListenerOnceUsingOn<GSelf extends TraitEventListenerOn<any, GKeyValueTupleList>, GKeyValueTupleList extends TGenericKeyValueTupleList> extends TraitEventListenerOnce<GSelf, GKeyValueTupleList> {
  once<GKey extends TInferKeyValueTupleListKeys<GKeyValueTupleList>>(
    this: GSelf,
    key: GKey,
    callback: (value: TInferKeyValueTupleListValueFromKey<GKeyValueTupleList, GKey>) => void,
  ): TEventListenerOnUnsubscribe {
    return EventListenerOnce<GSelf, GKey>(this, key, callback);
  }
}
