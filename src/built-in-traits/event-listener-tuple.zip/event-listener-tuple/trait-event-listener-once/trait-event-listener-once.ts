import { Trait } from '../../../core/traits/trait-decorator';
import {
  TEventListenerOnUnsubscribe, TGenericKeyValueTupleList, TInferKeyValueTupleListKeys,
  TInferKeyValueTupleListValueFromKey,
} from '../event-listener-types';

@Trait()
export abstract class TraitEventListenerOnce<GSelf, GKeyValueTupleList extends TGenericKeyValueTupleList> {
  abstract once<GKey extends TInferKeyValueTupleListKeys<GKeyValueTupleList>>(
    this: GSelf,
    key: GKey,
    callback: (value: TInferKeyValueTupleListValueFromKey<GKeyValueTupleList, GKey>) => void,
  ): TEventListenerOnUnsubscribe;
}

// export type TEmptyTraitEventListenerOnce = TraitEventListenerOnce<any, TEmptyKeyValueTupleUnion>;
// export type TGenericTraitEventListenerOnce = TraitEventListenerOnce<any, TGenericKeyValueTupleUnion>;
//
// export type TInferTraitEventListenerOnceGKeyValueTupleUnion<GTrait extends TEmptyTraitEventListenerOnce> =
//   GTrait extends TraitEventListenerOnce<any, infer GKeyValueTupleUnion>
//     ? GKeyValueTupleUnion
//     : never;

