import { Trait } from '../../../../core/traits/trait-decorator';
import { TGenericKeyValueTupleUnion, } from '../../event-listener-types';
import { ITypedEventTarget } from '../event-target-types';

@Trait()
export abstract class TraitEventListenerToEventTarget<GSelf, GKeyValueTupleUnion extends TGenericKeyValueTupleUnion> {
  abstract toEventTarget(): ITypedEventTarget<GKeyValueTupleUnion>;
}


export type TGenericTraitEventListenerToEventTarget = TraitEventListenerToEventTarget<any, TGenericKeyValueTupleUnion>;

export type TInferTraitEventListenerToEventTargetGKeyValueTupleUnion<GTrait extends TGenericTraitEventListenerToEventTarget> =
  GTrait extends TraitEventListenerToEventTarget<any, infer GKeyValueTupleUnion>
    ? GKeyValueTupleUnion
    : never;

