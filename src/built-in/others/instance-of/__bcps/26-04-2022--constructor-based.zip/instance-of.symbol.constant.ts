export const INSTANCE_OF = Symbol('instanceOf');
