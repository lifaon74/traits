export * from './create-instance-of-function'
export * from './instance-of.function-definition'
export * from './instance-of.symbol.constant'
export * from './instance-of.trait'
